for i in range(0, 5):
    if i < 3:
        print i, "is smaller than 3"
    elif i == 3:
        print i, "is 3"
    else:
        print i, "is greater than 3"
